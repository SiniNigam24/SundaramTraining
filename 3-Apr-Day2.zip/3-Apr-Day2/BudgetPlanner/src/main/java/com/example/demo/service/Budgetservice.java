package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;

import com.example.demo.model.BudgetModel;

@Service 
public class Budgetservice {
	
	
	ArrayList<BudgetModel> bl=new ArrayList();
public List<BudgetModel> getDetails() {
		
		return bl;}

	
	public List<BudgetModel> addMany(List<BudgetModel> list){
		bl.addAll(list);
		return list;}
	

//	public BudgetModel updateData( int id) {
//	      BudgetModel obj=null;
//		for(BudgetModel i:bl) {
//			
//			if(i.getUserId()==id) {
//				i.setMonth("April");
//				i.setCategory("State");
//				i.setAmount(2000);
//				obj=i;
//			}
//			
//		}
//		return obj;
//		}
	
	public ResponseEntity<BudgetModel> updateData( int id) {
	      BudgetModel obj=null;
		for(BudgetModel i:bl) {
			
			if(i.getUserId()==id) {
				i.setMonth("April");
				i.setCategory("State");
				i.setAmount(2000);
				obj=i;
			}
			
		}
		return new ResponseEntity<BudgetModel>(obj,HttpStatus.OK);
		}
	
	
	
	
	
	
	
}
