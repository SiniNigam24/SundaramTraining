package com.example.demo.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.BudgetModel;
import com.example.demo.service.Budgetservice;

@RestController

public class BudgetController {
	
	
	@Autowired
	Budgetservice bs;
	
//	@PostMapping("/addUser")
//	public String save(@RequestBody BudgetModel b) {
//		
//		
//			
//		}
//		else
//		
//		return "amount or userid can not be null!" ;
//		
//		
//}
//	}
	
	
	@GetMapping("/getUser")
	
	public List<BudgetModel> getDetail() {
		
		return bs.getDetails();}

	@PostMapping("/addMany")
	public List<BudgetModel> addMany(@RequestBody List<BudgetModel> list){
		
		return bs.addMany(list) ;}
	
	@PutMapping("/update/{id}")
	public ResponseEntity<BudgetModel> update(@PathVariable("id") int id) {
	
		
		return bs.updateData(id);
		}
	
	
	
}
