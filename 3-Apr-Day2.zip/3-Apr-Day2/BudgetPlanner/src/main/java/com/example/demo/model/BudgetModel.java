package com.example.demo.model;

public class BudgetModel {
   
	
	
	private int userId;
	private  double amount;
	private  String category;
	private  String month;
	public BudgetModel( int userId, double amount, String category, String month) {
		super();
	
		this.userId = userId;
		this.amount = amount;
		this.category = category;
		this.month = month;
	}
	
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getMonth() {
		return month;
	}
	public void setMonth(String month) {
		this.month = month;
	}

	@Override
	public String toString() {
		return "BudgetModel [userId=" + userId + ", amount=" + amount + ", category=" + category + ", month=" + month
				+ "]";
	}
	
}
